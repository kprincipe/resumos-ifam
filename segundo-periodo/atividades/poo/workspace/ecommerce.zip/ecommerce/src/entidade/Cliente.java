package entidade;

public class Cliente {
	private int codigo;
	private String cpfcnpj;
	private String nome;
	private String endereco;
	private String telefone;
	private String email;
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getCpfcnpj() {
		return cpfcnpj;
	}
	public void setCpfcnpj(String cpfcnpj) {
		this.cpfcnpj = cpfcnpj;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Cliente [codigo=" + codigo + ", cpfcnpj=" + cpfcnpj + ", nome=" + nome + ", endereco=" + endereco
				+ ", telefone=" + telefone + ", email=" + email + "]";
	}
	
	
}
